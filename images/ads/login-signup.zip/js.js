$(document).ready( () => {
    $(".btnlogin").click( () => {
        $(".logi").show(1000);
    });
});

$(document).ready( () => {
    $(".btnlogin").click( () => {
        $(".reg").hide(1000);
    });
});

$(document).ready( () => {
    $(".btnreg").click( () => {
        $(".reg").show(1000);
    });
});

$(document).ready( () => {
    $(".btnreg").click( () => {
        $(".logi").hide(1000);
    });
});

$(document).ready( () => {
    $("#usersvg").click( () => {
        $(".logi").hide(1000);
    });
});

$(document).ready( () => {
    $("#usersvg").click( () => {
        $(".reg").hide(1000);
    });
});




$(document).ready( () => {
    $(".btnlogin").click( () => {
        $(".login_box").addClass("active", 1000);
    });
});

$(document).ready( () => {
    $(".btnreg").click( () => {
        $(".login_box").addClass("active", 1000);
    });
});

$(document).ready( () => {
    $("#usersvg").click( () => {
        $(".login_box").removeClass("active", 1000);
    });
});